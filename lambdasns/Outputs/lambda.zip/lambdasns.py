import boto3
 
def notification(event, context):
    # Replace 'your_topic_arn' with the actual ARN of your SNS topic
    topic_arn = 'your_topic_arn'
    
    # Replace 'your_sender_email' with the email address you want to use as the sender
    sender_email = 'your_sender_email'
    
    # Replace 'your_user_id' with the actual user ID to whom you want to send the email
    user_id = 'your_user_id'
    
    # Create an SNS client
    sns_client = boto3.client('sns')
    
    # Create the email message
    email_subject = 'Subject of your email'
    email_body = 'Body of your email'
    
    # Publish the message to the specified SNS topic
    response = sns_client.publish(
        TopicArn=topic_arn,
        Message=email_body,
        Subject=email_subject,
        MessageStructure='string'
    )
    
    # Get the message ID from the response
    message_id = response['MessageId']
    
    # Print the message ID for reference
    print(f'MessageId: {message_id}')
    
    # Send email using SES (Simple Email Service)
    ses_client = boto3.client('ses')
    response = ses_client.send_email(
        Source=sender_email,
        Destination={
            'ToAddresses': [user_id],
        },
        Message={
            'Subject': {
                'Data': email_subject,
            },
            'Body': {
                'Text': {
                    'Data': email_body,
                },
            },
        },
    )
    
    # Print the SES response for reference
    print(response)